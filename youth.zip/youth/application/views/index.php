
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<title>My taste | HOME</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>./application/css/style.css">
</head>
<style type="text/css">
	
	body{
		background: url(<?php echo base_url('assets/images/grup.JPG');?>);
		background-size: cover;
	}
	}
</style>
<body>
	<header>
		<div class="container">
			<div id="brand">
				<img src="assets/images/youth.png" width="100px">
				<nav>
				<ul>
					<li class='link'><a href="index.php"><strong>home</strong></a></li>
					<li class='link'><a href="index.php?page=portifolio"><strong>portifolio</strong></a></li>
					<li class='link'><a href="index.php?page=services"><strong>services</strong></a></li>
					<li class='link'><a href="index.php?page=contacts"><strong>contacts</strong></a></li>
					<li class='link'><a href="index.php?page=about"><strong>about</strong></a></li>
					<li class='link'><a href="index.php?page=login"><strong>log in</strong></a></li>
				</ul>
			</nav>
			</div>	
		</div>
	</header>
	<section id="showcase">
		<div class="container">
			<h1>My taste brand</h1>
			<p>put God first</p>
		</div>
	</section>
	<section id="boxes">
		<div class="container">
			<div class="box">
				<img src="">
			</div>
		</div>
		
	</section>

	<!-- <footer>
		<p>my taste brand copyright &copy</p>
	</footer> -->
</body>
</html>
<?php
if(isset($_GET['page'])){
	$file = $_GET['page'];
	$dir = scandir('./application/views/includes', 0);
	unset($dir[0], $dir[1]);
	//print_r($dir);
	include('includes'.'/'.$file.'.php');	
}
?>
