<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form>
		<input type="text" name="login" placeholder="login">
		<button type='submit'name='submit' >Login</button>
	</form>
	</form>
</body>
</html>