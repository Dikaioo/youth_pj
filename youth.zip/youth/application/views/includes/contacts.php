<?php  ?>

<!DOCTYPE html>
<html>
<head>
	<title>contact us</title>
</head>
<style type="text/css">
	input{
		padding: 10px;
		margin: 10px;
	}


</style>
<body>
	<input type="text" name="fullname" class="form-input" placeholder="fulllname" required="">
	<input type="email" name="email" class="" placeholder="enter email" required="">
	<input type="date" name="dob" class="" placeholder="select DOB" required="">
	<input type="password" name="password" class="" placeholder="enter password" required="">
	<input type="submit" name="" class="" placeholder="">

</body>
</html>

